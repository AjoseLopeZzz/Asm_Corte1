var typed = new Typed(".auto-type", {
  strings: ["La organización es la clave del éxito.!"],
  typeSpeed: 50,
  backspeed: 50,
  loop: true,
});
