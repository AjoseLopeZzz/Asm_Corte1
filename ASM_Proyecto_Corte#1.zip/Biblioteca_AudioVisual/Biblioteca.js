var typed = new Typed(".auto-type", {
  strings: ["En la calma y la serenidad encuentro mi paz interior.!"],
  typeSpeed: 50,
  backspeed: 50,
  loop: true,
});
// Fin primera Parte //
