/* eslint-disable no-undef, no-unused-vars */
//DECLARACIONES

// Variable donde se almacena el contenedor del mensaje
let snackbarContainer;
// FUNCIÓN DE CONFIGURACIÓN
function setup() {
  // Se obtiene el elemento HTML con id "mensaje-interactivo"
  snackbarContainer = select("#mensaje-interactivo").elt;
  // Se agrega el evento mouseClicked al elemento con id "enlace-interactivo"
  select("#enlace-interactivo").mouseClicked(mostrarMensaje);
}

// FUNCIÓN QUE SE LLAMA AL PRESIONAR CLIC EN EL ENLACE
function mostrarMensaje() {
  // Muestra un mensaje
  let data = { message: "Mensaje mostrado" };
  snackbarContainer.MaterialSnackbar.showSnackbar(data);
}
